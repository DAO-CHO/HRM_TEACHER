package com.tbt.bachtung.hrm_teacher;

import androidx.annotation.NonNull;
import androidx.annotation.Nullable;
import androidx.appcompat.app.AppCompatActivity;

import android.content.Intent;
import android.graphics.Bitmap;
import android.os.Bundle;
import android.provider.MediaStore;
import android.util.Log;
import android.view.View;
import android.widget.ArrayAdapter;
import android.widget.Button;
import android.widget.EditText;
import android.widget.ImageView;
import android.widget.ListView;
import android.widget.Toast;

import com.google.android.gms.tasks.OnFailureListener;
import com.google.android.gms.tasks.OnSuccessListener;
import com.google.firebase.database.DataSnapshot;
import com.google.firebase.database.DatabaseError;
import com.google.firebase.database.DatabaseReference;
import com.google.firebase.database.FirebaseDatabase;
import com.google.firebase.database.ValueEventListener;
import com.google.firebase.storage.FirebaseStorage;
import com.google.firebase.storage.StorageReference;
import com.google.firebase.storage.UploadTask;

import java.io.ByteArrayOutputStream;
import java.util.ArrayList;
import java.util.Calendar;
import java.util.HashMap;

public class Update_Teacher extends AppCompatActivity {

    ArrayAdapter<String> adapter_update;
    String TAG = "FIREBASE";
    FirebaseStorage storage = FirebaseStorage.getInstance();
    Button btnSave_update, btnupdate, btncancle, btnlibary, btndelete;
    EditText hoten, khoa, gioitinh, ngaysinh, diachi, bomon, hocvi, magiangvien;
    ImageView imgHinh_update;
    int REQUEST_CODE_IMAGE = 1;
    StorageReference storageRef = storage.getReferenceFromUrl("gs://teacherhrm-1b66b.appspot.com");

    @Override
    protected void onCreate(Bundle savedInstanceState) {
        super.onCreate(savedInstanceState);
        setContentView(R.layout.activity_update__teacher);



        SaveIMG_update();
        btnSave_update.setOnClickListener(new View.OnClickListener() {
            @Override
            public void onClick(View v) {
                Intent intent = new Intent(MediaStore.ACTION_IMAGE_CAPTURE);
                startActivityForResult(intent, REQUEST_CODE_IMAGE);
            }
        });
        Display();
        getContactdetail();
        Update();
        btnupdate.setOnClickListener(new View.OnClickListener() {
            @Override
            public void onClick(View v) {
                Calendar calendar = Calendar.getInstance();

                StorageReference moutainRef = storageRef.child("IMAGE" + calendar.getTimeInMillis() + "png");
                imgHinh_update.setDrawingCacheEnabled(true);
                imgHinh_update.buildDrawingCache();
                Bitmap bitmap = imgHinh_update.getDrawingCache();
                ByteArrayOutputStream baos = new ByteArrayOutputStream();
                bitmap.compress(Bitmap.CompressFormat.PNG, 100, baos);
                byte[] data = baos.toByteArray();

                UploadTask uploadTask = moutainRef.putBytes(data);
                uploadTask.addOnFailureListener(new OnFailureListener() {
                    @Override
                    public void onFailure(@NonNull Exception e) {
                        Toast.makeText(Update_Teacher.this, "LỖI!", Toast.LENGTH_SHORT).show();
                    }
                }).addOnSuccessListener(new OnSuccessListener<UploadTask.TaskSnapshot>() {
                    @Override
                    public void onSuccess(UploadTask.TaskSnapshot taskSnapshot) {

                        Toast.makeText(Update_Teacher.this, "CẬP NHẬT THÀNH CÔNG!", Toast.LENGTH_SHORT).show();

                    }
                });
                FirebaseDatabase database = FirebaseDatabase.getInstance();
                DatabaseReference myRef = database.getReference("GIANGVIEN");

                String maGv = magiangvien.getText().toString();
                String hoTen = hoten.getText().toString();
                String Khoa = khoa.getText().toString();
                String gioiTinh = gioitinh.getText().toString();
                String boMon = bomon.getText().toString();
                String ngaySinh = ngaysinh.getText().toString();
                String hocVi = hocvi.getText().toString();
                String diaChi = diachi.getText().toString();

                myRef.child(maGv).child("HoTen").setValue(hoTen);
                myRef.child(maGv).child("Khoa").setValue(Khoa);
                myRef.child(maGv).child("GioiTinh").setValue(gioiTinh);
                myRef.child(maGv).child("BoMon").setValue(boMon);
                myRef.child(maGv).child("NgaySinh").setValue(ngaySinh);
                myRef.child(maGv).child("HocVi").setValue(hocVi);
                myRef.child(maGv).child("DiaChi").setValue(diaChi);
                finish();

            }
        });
        ChooseIMG();
        btnlibary.setOnClickListener(new View.OnClickListener() {
            @Override
            public void onClick(View v) {
                Intent intent = new Intent(MediaStore.ACTION_IMAGE_CAPTURE);
                startActivityForResult(intent, REQUEST_CODE_IMAGE);
            }
        });

        Cancle();
        btncancle.setOnClickListener(new View.OnClickListener() {
            @Override
            public void onClick(View v) {
                Intent intent = new Intent(Update_Teacher.this, Listview_teacher.class);
                startActivity(intent);
            }
        });
        btndelete = (Button) findViewById(R.id.actiondelete_update);
        btndelete.setOnClickListener(new View.OnClickListener() {
            @Override
            public void onClick(View v) {
                Delete(v);
            }
        });
    }

    @Override
    protected void onActivityResult(int requestCode, int resultCode, @Nullable Intent data) {
        if(requestCode == REQUEST_CODE_IMAGE && resultCode == RESULT_OK && data != null){
            Bitmap bitmap = (Bitmap) data.getExtras().get("data");
            imgHinh_update.setImageBitmap(bitmap);
        }
        super.onActivityResult(requestCode, resultCode, data);
    }

    private void SaveIMG_update() {
        btnSave_update = (Button) findViewById(R.id.btnchupanh_update);
        imgHinh_update = (ImageView) findViewById(R.id.imglibrary_update);
    }
    private void Update(){
        btnupdate = (Button) findViewById(R.id.btnactionadd_update);

    }
    private void Cancle(){
        btncancle = (Button) findViewById(R.id.actioncancle_update);
    }
    private void ChooseIMG(){
        btnlibary = (Button) findViewById(R.id.btnchonanh_update);
    }
    private void getContactdetail(){
        Intent intent = getIntent();
        final String key = intent.getStringExtra("KEY");

        FirebaseDatabase database = FirebaseDatabase.getInstance();
        DatabaseReference myRef = database.getReference("GIANGVIEN");

        myRef.child(key).addListenerForSingleValueEvent(new ValueEventListener() {
            @Override
            public void onDataChange(DataSnapshot dataSnapshot) {
                try {
                    HashMap<String, Object> hashMap = (HashMap<String, Object>) dataSnapshot.getValue();
                    magiangvien.setText(key);
                    hoten.setText(hashMap.get("HoTen").toString());
                    bomon.setText(hashMap.get("BoMon").toString());
                    diachi.setText(hashMap.get("DiaChi").toString());
                    ngaysinh.setText(hashMap.get("NgaySinh").toString());
                    khoa.setText(hashMap.get("Khoa").toString());
                    hocvi.setText(hashMap.get("HocVi").toString());
                    gioitinh.setText(hashMap.get("GioiTinh").toString());
                } catch (Exception ex) {
                    Log.e("LOI_JSON", ex.toString());
                }
            }
            @Override
            public void onCancelled(DatabaseError databaseError) {
                Log.w("LOI_CHI_TIET", "loadPost:onCancelled", databaseError.toException());
            }
        });
    }
    private void Display(){
        magiangvien = findViewById(R.id.edtmagv_update);
        hoten = findViewById(R.id.edthoten_update);
        gioitinh = findViewById(R.id.edtgioitinh_update);
        hocvi = findViewById(R.id.edthocvi_update);
        ngaysinh = findViewById(R.id.edtngaysinh_update);
        khoa = findViewById(R.id.edtkhoa_update);
        bomon = findViewById(R.id.edttbomon_update);
        diachi = findViewById(R.id.edtdiachi_update);
    }
    private void Delete(View v){

        String key =magiangvien.getText().toString();
        FirebaseDatabase database = FirebaseDatabase.getInstance();
        DatabaseReference myRef = database.getReference("GIANGVIEN");
        myRef.child(key).removeValue();
        finish();
    }
}