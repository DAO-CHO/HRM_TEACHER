package com.tbt.bachtung.hrm_teacher;

import android.content.Context;
import android.provider.ContactsContract;
import android.view.LayoutInflater;
import android.view.View;
import android.view.ViewGroup;
import android.widget.BaseAdapter;
import android.widget.ImageView;
import android.widget.TextView;

import org.w3c.dom.Text;

import java.util.List;

public class Teacher_Adapter extends BaseAdapter {

    private Context context;
    private int layout;
    private List<Teacher> teacherList;

    public Teacher_Adapter(Context context, int layout, List<Teacher> teacherList) {
        this.context = context;
        this.layout = layout;
        this.teacherList = teacherList;
    }

    @Override
    public int getCount() {
        return teacherList.size();
    }

    @Override
    public Object getItem(int position) {
        return null;
    }

    @Override
    public long getItemId(int position) {
        return 0;
    }
    private class ViewHolder{
        ImageView img;
        TextView txtTen, txtkhoa, txtbomon;
    }

    @Override
    public View getView(int position, View convertView, ViewGroup parent) {
        ViewHolder holder;
        if(convertView == null) {
            LayoutInflater inflater = (LayoutInflater) context.getSystemService(Context.LAYOUT_INFLATER_SERVICE);
            convertView = inflater.inflate(layout, null);
            holder = new ViewHolder();
            //ánh xạ
            holder.txtTen = (TextView) convertView.findViewById(R.id.textviewhoten_line);
            holder.txtkhoa = (TextView) convertView.findViewById(R.id.textviewkhoa_line);
            holder.txtbomon = (TextView) convertView.findViewById(R.id.textviewbomon_line);
            holder.img = (ImageView) convertView.findViewById(R.id.imageview_line);
            convertView.setTag(holder);
        }else{
            holder = (ViewHolder) convertView.getTag();
        }


        //gán giá trị
        Teacher teacher = teacherList.get(position);

        holder.txtTen.setText(teacher.getTen());
        holder.txtkhoa.setText(teacher.getKhoa());
        holder.txtbomon.setText(teacher.getBomon());
        holder.img.setImageResource(teacher.getImage());


        return convertView;
    }
}
