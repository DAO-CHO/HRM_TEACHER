package com.tbt.bachtung.hrm_teacher;

import androidx.annotation.NonNull;
import androidx.annotation.Nullable;
import androidx.appcompat.app.AppCompatActivity;

import android.content.Intent;
import android.graphics.Bitmap;
import android.net.Uri;
import android.os.Bundle;
import android.provider.MediaStore;
import android.util.Log;
import android.view.View;
import android.widget.ArrayAdapter;
import android.widget.Button;
import android.widget.EditText;
import android.widget.ImageView;
import android.widget.Spinner;
import android.widget.Toast;

import com.google.android.gms.tasks.OnFailureListener;
import com.google.android.gms.tasks.OnSuccessListener;
import com.google.firebase.database.DatabaseReference;
import com.google.firebase.database.FirebaseDatabase;
import com.google.firebase.storage.FileDownloadTask;
import com.google.firebase.storage.FirebaseStorage;
import com.google.firebase.storage.StorageReference;
import com.google.firebase.storage.UploadTask;


import java.io.ByteArrayOutputStream;
import java.net.URI;
import java.util.Calendar;

import static android.widget.Toast.*;

public class Add_Teacher extends AppCompatActivity {

    FirebaseStorage storage = FirebaseStorage.getInstance();
    Button btnSave, btnInsert, btnCancle;
    ImageView imgHinh;
    EditText hoten, khoa, gioitinh, ngaysinh, diachi, bomon, hocvi, magiangvien;
    int REQUEST_CODE_IMAGE = 1;

    @Override
    protected void onCreate(Bundle savedInstanceState) {
        super.onCreate(savedInstanceState);
        setContentView(R.layout.activity_add__teacher);


        // Create a storage reference from our app
        final StorageReference storageRef = storage.getReferenceFromUrl("gs://teacherhrm-1b66b.appspot.com");


        SaveIMG();


        btnSave.setOnClickListener(new View.OnClickListener() {
            @Override
            public void onClick(View v) {
                Intent intent = new Intent(MediaStore.ACTION_IMAGE_CAPTURE);
                startActivityForResult(intent, REQUEST_CODE_IMAGE);
            }
        });

        Add();
        btnInsert.setOnClickListener(new View.OnClickListener() {
            @Override
            public void onClick(View v) {
                Calendar calendar = Calendar.getInstance();

                StorageReference moutainRef = storageRef.child("IMAGE" + calendar.getTimeInMillis() + "png");
                imgHinh.setDrawingCacheEnabled(true);
                imgHinh.buildDrawingCache();
                Bitmap bitmap = imgHinh.getDrawingCache();
                ByteArrayOutputStream baos = new ByteArrayOutputStream();
                bitmap.compress(Bitmap.CompressFormat.PNG, 100, baos);
                byte[] data = baos.toByteArray();

                UploadTask uploadTask = moutainRef.putBytes(data);
                uploadTask.addOnFailureListener(new OnFailureListener() {
                    @Override
                    public void onFailure(@NonNull Exception e) {
                        makeText(Add_Teacher.this, "LỖI!", LENGTH_SHORT).show();
                    }
                }).addOnSuccessListener(new OnSuccessListener<UploadTask.TaskSnapshot>() {
                    @Override
                    public void onSuccess(UploadTask.TaskSnapshot taskSnapshot) {

                        makeText(Add_Teacher.this, "GIẢNG VIÊN ĐÃ ĐƯỢC THÊM!", LENGTH_SHORT).show();

                    }
                });

                FirebaseDatabase database = FirebaseDatabase.getInstance();
                DatabaseReference myRef = database.getReference("GIANGVIEN");
                String maGv = magiangvien.getText().toString();
                String hoTen = hoten.getText().toString();
                String Khoa = khoa.getText().toString();
                String gioiTinh = gioitinh.getText().toString();
                String boMon = bomon.getText().toString();
                String ngaySinh = ngaysinh.getText().toString();
                String hocVi = hocvi.getText().toString();
                String diaChi = diachi.getText().toString();

                myRef.child(maGv).child("HoTen").setValue(hoTen);
                myRef.child(maGv).child("Khoa").setValue(Khoa);
                myRef.child(maGv).child("GioiTinh").setValue(gioiTinh);
                myRef.child(maGv).child("BoMon").setValue(boMon);
                myRef.child(maGv).child("NgaySinh").setValue(ngaySinh);
                myRef.child(maGv).child("HocVi").setValue(hocVi);
                myRef.child(maGv).child("DiaChi").setValue(diaChi);
                finish();


            }
        });

        Cancle();
        btnCancle.setOnClickListener(new View.OnClickListener() {
            @Override
            public void onClick(View v) {
                Intent intent = new Intent(Add_Teacher.this, Add_Revise_Delete.class);
                startActivity(intent);
            }
        });

    }

    @Override
    protected void onActivityResult(int requestCode, int resultCode, @Nullable Intent data) {

        if(requestCode == REQUEST_CODE_IMAGE && resultCode == RESULT_OK && data != null){
            Bitmap bitmap = (Bitmap) data.getExtras().get("data");
            imgHinh.setImageBitmap(bitmap);
        }
        super.onActivityResult(requestCode, resultCode, data);
    }

    private void SaveIMG(){
        btnSave = (Button) findViewById(R.id.btnchupanh);
        imgHinh = (ImageView) findViewById(R.id.imglibrary);
    }
    private void Add(){
        magiangvien = (EditText) findViewById(R.id.edtmagv);
        hoten = (EditText) findViewById(R.id.edthoten);
        khoa = (EditText) findViewById(R.id.edttkhoa);
        gioitinh = (EditText) findViewById(R.id.edtgioitinh);
        ngaysinh = (EditText) findViewById(R.id.edtngaysinh);
        diachi = (EditText) findViewById(R.id.edtdiachi);
        bomon = (EditText) findViewById(R.id.edtbomon);
        hocvi = (EditText) findViewById(R.id.edthocvi);
        btnInsert = (Button) findViewById(R.id.btnactionadd);

    }
    private void Cancle(){
        btnCancle = (Button) findViewById(R.id.actioncancle);
    }


}