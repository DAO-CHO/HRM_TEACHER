package com.tbt.bachtung.hrm_teacher;

public class Teacher {
    private String Ten;
    private String Khoa;
    private String Bomon;
    private int Image;

    public Teacher(String ten, String khoa, String bomon, int image) {
        Ten = ten;
        Khoa = khoa;
        Bomon = bomon;
        Image = image;
    }

    public String getTen() {
        return Ten;
    }

    public void setTen(String ten) {
        Ten = ten;
    }

    public String getKhoa() {
        return Khoa;
    }

    public void setKhoa(String khoa) {
        Khoa = khoa;
    }

    public String getBomon() {
        return Bomon;
    }

    public void setBomon(String bomon) {
        Bomon = bomon;
    }

    public int getImage() {
        return Image;
    }

    public void setImage(int image) {
        Image = image;
    }
}
